package repository;

public interface IVehicleRepository {
    boolean deleteVehicleByControlPlate(String controlPlate);
}
