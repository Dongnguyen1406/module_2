package view;

import controller.MenuController;

public class View {
    public static void main(String[] args) {
        MenuController.displayMenu();
    }
}
